import React,{useState}  from 'react'
import  axios  from 'axios';
import form from './form.css'

import {Link,useHistory} from 'react-router-dom';

import {Navbar,Nav,Container,Form,Button}  from 'react-bootstrap' 


export default function Login() {
  
const history = useHistory();
  const [inputState,setInputState]=useState(
    {}
  )

    const handleChange=(event)=>{
       
event.persist();
console.log("handle change",event.target.value)
let {name,value}=event.target;


setInputState({...inputState,[name]:value})

history.push("./Adddata");

    }
    const submit=(event)=>{
event.preventDefault();
console.log('inputState',inputState);
const user=inputState;
axios.post('https://nodeprojectapi.herokuapp.com/login',user)
.then(res =>{
   console.log("axios",res);
   
})
.catch(err=>{
   console.log(err);
})

    }

    return (
       <Container className="con">
        <div class="wrapper">
         <div class="title-text">
            <div class="title login">
               Login Form
            </div>
          
         </div>
         <div class="form-container1">
            <div class="slide-controls">
               <input type="radio" name="slide" id="login" checked/>
               <input type="radio" name="slide" id="signup"/>
               <label for="login" class="slide login">
               <Link className="link" to="/Login">Login</Link>
               </label>
          
            </div>
            <div class="form-inner">
               <form action="#" class="login" onSubmit={submit}>
                  <div class="field">
                  
                     <input type="email" name="email" onChange={handleChange} placeholder="Email Address" />
              
                  </div>

                  <div class="field">
                     <input type="password"  name="password" onChange={handleChange} placeholder="Password" />
              
                  </div>
             
                  <div class="field btn">
                     <div class="btn-layer"></div>
                     <input type="submit" value="Login"/>
                  </div>
                  <div class="signup-link">
                  <Link to="/Register">
                     Not a member? <a href="">Signup now</a></Link>
                  </div>
               </form>
            
            </div>
         </div>
      </div>
      </Container>
    )
}
