import React  from 'react'

import {Navbar,Nav,Container,NavDropdown,Button ,FormControl}  from 'react-bootstrap' 

import {Link,useHistory} from 'react-router-dom';

import './Header.css'

export default function Header() {
 

  const history=useHistory();

  function logout(){

    history.push('./Login')
  }
  const name="Header"
    return (
        <Navbar className="nav"  expand="lg">
        <Container>
          <Navbar.Brand href="#home"></Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="me-auto">
       
 
          
              <Nav.Link as={Link} to="/Login">Login</Nav.Link>
      

               
               
                 <Nav.Link as={Link} to="/Register1">RegForm</Nav.Link>
                 <Nav.Link as={Link} to="/Adddata">ADD DATA</Nav.Link>
            
            
                 {/* <NavDropdown title="Dropdown" id="basic-nav-dropdown">
          <NavDropdown.Item    as={Link} to="/Movies/Movies">Admin</NavDropdown.Item>
     
          <NavDropdown.Item href="#action/3.4">Separated link</NavDropdown.Item>
        </NavDropdown> */}
              
          
         <Button onClick={logout}>Logout</Button>
            
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    )
}

