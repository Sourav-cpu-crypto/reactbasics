import React,{lazy,Suspense} from 'react'
import {Route,Switch,BrowserRouter as Router} from 'react-router-dom'

import RegForm1 from '../../auth/RegForm1.js'
import Login from '../../auth/login.js'
import Adddata from '../../auth/Adddata.js'
import GetData from '../../auth/GetData.js'
import Header from '../Header/Header.js'
const feedback=lazy(()=>import("./feedback.js"));

export default function Routes() {
  
    return (
      
        <Router>

        <Header/>
     
        <Switch>
     
   
        
            <Suspense fallback={<h1>Loading...</h1>}>
      
         
  
         
             <Route path="/Login" component={Login}></Route>


               <Route path="/Register1" component={RegForm1}></Route>
               <Route path="/Adddata" component={Adddata}></Route>
         
               <Route path="/Getdata" component={GetData}></Route>
  
     </Suspense>
  
       <Route render={()=><h1>error not found</h1>}/>
   
        </Switch>
    </Router>
    )
}

