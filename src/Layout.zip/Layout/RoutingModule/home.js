import React from 'react'

export const home = () => {
    return (
        <div>
            hello
        </div>
    )
}
