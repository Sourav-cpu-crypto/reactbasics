import React from 'react'

const feedback = () => {
    return (
        <div>
            feedback
        </div>
    )
}

export default feedback
